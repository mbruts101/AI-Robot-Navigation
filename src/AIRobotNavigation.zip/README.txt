Michael Brutsch
bruts101@mail.chapman.edu
1933153
Julien Fournell
1935094
fourn106@mail.chapman.edu


Sources Used: Received help from Graduate Student Jordan Ott, Chapman 2017.
